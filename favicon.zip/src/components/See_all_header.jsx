import React, { useState } from 'react';
import { useNavigate } from 'react-router';
const See_all_header = () => {

    const [coins, setCoins] = useState(300);
    
    const navigate = useNavigate();

    return (
        <header className='d-flex justify-content-between align-items-center' style={{ padding: '4px 19px' }}>
            <div>
                <i class="fa-solid fa-chevron-left me-2" style={{cursor:'pointer'}} onClick={()=>navigate('/start-screen')}></i>
                <span>Quiz Topics</span>

            </div>
            <div className='d-flex align-items-center'>
                <button className='d-flex justify-content-between align-items-center' style={{ padding: '5px 9px 5px 0px', backgroundColor: '#191a32', border: '0', borderRadius: '6px' }}>
                    <div>
                        <img src='/images/coin.png' width={'45%'} alt="Coin" />
                    </div>
                    <div className="text-white fw-bold" style={{ fontSize: '9px' }}>
                        <p className='m-0 p-0' style={{ color: '#6063af' }}>COINS</p>
                        <h6 className="m-0 fw-bold" style={{ fontSize: '11px' }}>{coins}</h6>
                    </div>

                </button>
               <span> <i class="fa-solid fa-bell ms-3"></i></span>

            </div>
        </header>
    )
}

export default See_all_header