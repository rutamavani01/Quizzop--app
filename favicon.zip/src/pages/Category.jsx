import React, { useState } from 'react';
import '../css/Style.css';
import See_all_header from '../components/See_all_header';
import { useNavigate } from 'react-router-dom';
import { trendingItems } from '../utils/utils.js';
import Top_Quiz from '../components/Top_Quiz';
import themeColors from '../utils/colors.js';

const Category = () => {
    const navigate = useNavigate();
    const [liked, setLiked] = useState({});
    const [searchQuery, setSearchQuery] = useState(''); 

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value); 
    };

    const handleLike = (quizId) => {
        setLiked((prevLiked) => ({
            ...prevLiked,
            [quizId]: !prevLiked[quizId],
        }));
    };

    const filteredItems = trendingItems.filter((quiz) =>
        quiz.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="d-flex justify-content-center align-items-center">
            <div className="container p-0 text-center text-light rounded" style={{ backgroundColor: themeColors.backgroundColor, maxWidth: '492px', border: '4px solid #3336708a', height: '100vh' }}>
                <See_all_header />

                <div className='d-flex justify-content-between p-3'>
                    <div
                        className="search-container"
                        style={{
                            display: 'flex',
                            alignItems: 'center',
                            backgroundColor: '#20213f',
                            border: '0.5px solid #26284c',
                            borderRadius: '8px',
                            padding: '8px',
                            gap: '8px',
                            width: '90%',
                        }}
                    >
                        <i className="fa-solid fa-magnifying-glass" style={{ color: '#8789c3', fontSize: '16px' }}></i>
                        <input
                            type="text"
                            placeholder="Search for topics you like"
                            className="custom-placeholder"
                            style={{
                                flex: 1,
                                backgroundColor: 'transparent',
                                border: 'none',
                                outline: 'none',
                                color: '#8789c3',
                                fontSize: '14px',
                            }}
                            value={searchQuery}
                            onChange={handleSearchChange}  
                        />
                    </div>
                    <button
                        onClick={() => console.log('Filter clicked')} 
                        style={{
                            backgroundColor: '#26284c',
                            border: 'none',
                            color: '#8789c3',
                            padding: '8px 12px',
                            borderRadius: '6px',
                            cursor: 'pointer',
                        }}
                    >
                        <i className="fa-solid fa-filter"></i>
                    </button>
                </div>

                <div className='d-flex flex-wrap justify-content-between text-white p-3 pb-0 pt-0 text-center'>
                    <div className='col-4 p-2'>
                        <div className='card' style={{ borderRadius: '12px', cursor: 'pointer' }} onClick={() => navigate('/contests')}>
                            <div className="text-center p-3" style={{ backgroundColor: 'white', borderRadius: '12px' }}>
                                <img src="./images/all_categories.png" alt="All Topics" className="img-fluid mb-3" width={70} height={70} />
                                <p className='text-dark m-0 p-0' style={{ fontSize: '11px', fontWeight: '700' }}>All Topics</p>
                            </div>
                        </div>
                    </div>

                    {filteredItems.map((quiz) => (
                        <div key={quiz.id} className='col-4 p-2'>
                            <Top_Quiz
                                objectData={quiz}
                                handleLike={() => handleLike(quiz.id)}
                                isLiked={liked[quiz.id]}
                                onClick={() => {
                                    const dynamicRoute = `/view-quiztopic/${quiz.title.toLowerCase().replace(' ', '-')}`;
                                    navigate(dynamicRoute);
                                }}
                            />
                        </div>
                    ))}

                </div>
            </div>
        </div>
    );
};

export default Category;
